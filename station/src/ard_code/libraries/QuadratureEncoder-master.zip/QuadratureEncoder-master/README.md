# QuadratureEncoder
Arduino Quadrature Encoder
